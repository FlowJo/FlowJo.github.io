////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2017 Josef Spidlen, Ph.D., FlowJo, LLC
//
// License
// The software is distributed under the terms of the 
// Artistic License 2.0
// http://www.r-project.org/Licenses/Artistic-2.0
// 
// Disclaimer
// This software and documentation come with no warranties of any kind.
// This software is provided "as is" and any express or implied 
// warranties, including, but not limited to, the implied warranties of
// merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the  copyright holder be liable for any direct, 
// indirect, incidental, special, exemplary, or consequential damages
// (including but not limited to, procurement of substitute goods or 
// services; loss of use, data or profits; or business interruption)
// however caused and on any theory of liability, whether in contract,
// strict liability, or tort arising in any way out of the use of this 
// software.    
//////////////////////////////////////////////////////////////////////////////


package com.flowjo.plugin.flowai;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import com.treestar.lib.file.FileUtil;
import com.flowjo.plugin.flowai.utils.FilenameUtils;
import com.treestar.flowjo.engine.EngineManager;
import com.treestar.flowjo.engine.utility.RFlowCalculator;

public class FlowAIRFlowCalc extends RFlowCalculator {
	
	// The path to the flowAI R script template from within the jar file
	private final static String flowAITemplatePath = "r/RScript.flowAI.Template.R";
	
	public File performFlowAI(File sampleFile, String sampleName, List<String> parameterNames, Map<String, String> options, String outputFolderPath, boolean useExistingFiles)
    {
		sampleName = sampleName.replaceAll(".ExtNode", "").replaceAll(".fcs", "").replaceAll(".LMD", "").trim();
		
        File outputFolder = new File(outputFolderPath);
        StringWriter scriptWriter = new StringWriter();
        File flowAIScript = composeRflowAIStatements(sampleFile, sampleName, parameterNames, options, outputFolder, scriptWriter);
        if(flowAIScript == null) return null;
        if(useExistingFiles && flowAIScript.exists()) return flowAIScript;
        
        String scriptFileName = (new StringBuilder()).append("RScript.flowAI.").append(System.currentTimeMillis()).append(".R").toString().replaceAll(" ", "_");
        try
        {
            fScriptFile = new File(outputFolderPath, scriptFileName);
            FileUtil.write(fScriptFile, scriptWriter.toString());
            executeRBatch(scriptFileName);
        }
        catch(Exception e) 
        {
            e.printStackTrace();
        }
        return flowAIScript;
    }

	protected File composeRflowAIStatements(File sampleFile, String sampleName, List<String> parameterNames, Map<String, String> options, File outputFolder, StringWriter scriptWriter)
    {
        InputStream scriptStream = FlowAIRFlowCalc.class.getResourceAsStream(flowAITemplatePath);
        
        String outFileName = (new StringBuilder()).append(FilenameUtils.fixFileNamePart(sampleName)).append(".flowAI").append(".csv").toString();
        if(outputFolder == null) outputFolder = sampleFile.getParentFile();
        
        File outFile = new File(outputFolder, outFileName);
        outFileName = outFile.getAbsolutePath();
        String dataFilePath = sampleFile.getAbsolutePath();
        // This is how FlowJo's flowMeans code is doing it; I just hope they tested it properly :-)
        if(EngineManager.isWindows()) outFileName = outFileName.replaceAll("\\\\", "/");
        if(EngineManager.isWindows()) dataFilePath = dataFilePath.replaceAll("\\\\", "/");
        
        String sParSecondFractionFR = options.get(FlowAI.sOptionNameSecondFractionFR);
        try {
        	if (Double.parseDouble(sParSecondFractionFR) < 0 || Double.parseDouble(sParSecondFractionFR) > 1) sParSecondFractionFR = "0.1";
        } catch (Exception e) {
        	sParSecondFractionFR = "0.1";
        }
        
        String sParMaxCptFs = options.get(FlowAI.sOptionNameMaxCptFs);
        try {
        	if(Double.parseDouble(sParMaxCptFs) < 1.0 || Double.parseDouble(sParMaxCptFs) > 100.0) sParMaxCptFs = "3";
        } catch (Exception e) {
        	sParMaxCptFs = "3";
        }
        
        String sParAlphaFR = options.get(FlowAI.sOptionNameAlphaFR);
        try {
        	if(Double.parseDouble(sParAlphaFR) < 0 || Double.parseDouble(sParAlphaFR) > 1) sParAlphaFR = "0.01";
        } catch (Exception e) {
        	sParAlphaFR = "0.01";
        }

        String sParRemoveFrom = options.get(FlowAI.sOptionNameRemoveFrom);
        try {
        	if (sParRemoveFrom == null || sParRemoveFrom.isEmpty())
            	sParRemoveFrom = FlowAI.removeChecks[0];
        	else {
        		boolean valid = false;
        		for (String s : FlowAI.removeChecks) {
        			if (s.equals(sParRemoveFrom)) { 
        				valid = true;
        				continue;
        			}
        		}
        		if (!valid)
        			sParRemoveFrom = FlowAI.removeChecks[0];
        	}
        } catch (Exception e) {
        	sParRemoveFrom = FlowAI.removeChecks[0];
        }
        
        String sParSideFM = options.get(FlowAI.sOptionNameSideFM);
        try {
        	if (sParSideFM == null || sParSideFM.isEmpty())
        		sParSideFM = FlowAI.sideFMOptions[0];
        	else {
        		boolean valid = false;
        		for (String s : FlowAI.sideFMOptions) {
        			if (s.equals(sParSideFM)) { 
        				valid = true;
        				continue;
        			}
        		}
        		if (!valid)
        			sParSideFM = FlowAI.sideFMOptions[0];
        	}
        } catch (Exception e) {
        	sParSideFM = FlowAI.sideFMOptions[0];
        }
                
        String sParPenValueFs = options.get(FlowAI.sOptionNamePenValueFs);
        if (sParPenValueFs == null || sParPenValueFs.isEmpty())
        	sParPenValueFs = "200";
        
        String sParDecompFR = options.get(FlowAI.sOptionNameDecompFR);
        if (sParDecompFR == null || sParDecompFR.isEmpty() || FlowAI.One.equals(sParDecompFR) || FlowAI.True.equals(sParDecompFR))
        	sParDecompFR = "TRUE"; // TRUE is the default here
        else
        	sParDecompFR = "FALSE";

        String sParOutlierFS = options.get(FlowAI.sOptionNameOutlierFS);
        if (sParOutlierFS == null || sParOutlierFS.isEmpty() || FlowAI.Zero.equals(sParOutlierFS) || FlowAI.False.equals(sParOutlierFS))
        	sParOutlierFS = "FALSE"; // FALSE is the default here
        else
        	sParOutlierFS = "TRUE";

        String sParDeleteWD = options.get(FlowAI.sOptionNameDeleteWD);
        if (sParDeleteWD == null || sParDeleteWD.isEmpty() || FlowAI.One.equals(sParDeleteWD) || FlowAI.True.equals(sParDeleteWD))
        	sParDeleteWD = "TRUE"; // TRUE is the default here
        else
        	sParDeleteWD = "FALSE";

        BufferedReader rTemplateReader = null;
        try {
			rTemplateReader = new BufferedReader(new InputStreamReader(scriptStream));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
        
        String scriptLine;
        try {
			while((scriptLine = rTemplateReader.readLine()) != null) 
			{
			    scriptLine = scriptLine.replaceAll("FJ_DATA_FILE_PATH", dataFilePath);
			    scriptLine = scriptLine.replaceAll("FJ_CSV_OUPUT_FILE", outFileName);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_SECOND_FRACTION_FR", sParSecondFractionFR);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_ALPHA_FR", sParAlphaFR);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_REMOVE_FROM", sParRemoveFrom);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_MAX_CPT_FS", sParMaxCptFs);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_PEN_VALUE_FS", sParPenValueFs);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_DECOMP_FR", sParDecompFR);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_OUTLIER_FS", sParOutlierFS);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_DELETE_WD", sParDeleteWD);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_SIDE_FM", sParSideFM);
			    
			    if(scriptLine.contains("FJ_PARAMS_LIST")) {
			    	String parListStr = "";
			    	for (String parName : parameterNames)
			    	{
			    		// Note that we don't want the TIME parameter to be in the parameter list given to the R script, 
			    		// but we would like the TIME parameter to be present in the FCS file.
			    		if(parName.compareToIgnoreCase("TIME") != 0) {
			    			if(!parListStr.isEmpty()) parListStr = (new StringBuilder()).append(parListStr).append(",").toString();
			    			parListStr = (new StringBuilder()).append(parListStr).append("\"").append(parName).append("\"").toString();
			    		}
			    		// System.out.println(parName);
			    	}
			    	// System.out.println("parListStr = " + parListStr);
			    	scriptLine = scriptLine.replaceAll("FJ_PARAMS_LIST", parListStr);
			    }
			    
			    scriptWriter.append(scriptLine).append('\n');

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        if(rTemplateReader != null) {
        	try { rTemplateReader.close(); }
        	catch (Exception e) { e.printStackTrace(); }
        }
        
        return outFile;
    }

}
