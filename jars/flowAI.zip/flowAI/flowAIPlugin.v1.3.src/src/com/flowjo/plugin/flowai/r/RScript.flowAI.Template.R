#######################################################################
#
# Copyright (c) 2017 Josef Spidlen, Ph.D., FlowJo, LLC
#
# License
# The software is distributed under the terms of the 
# Artistic License 2.0
# http://www.r-project.org/Licenses/Artistic-2.0
# 
# Disclaimer
# This software and documentation come with no warranties of any kind.
# This software is provided "as is" and any express or implied 
# warranties, including, but not limited to, the implied warranties of
# merchantability and fitness for a particular purpose are disclaimed.
# In no event shall the  copyright holder be liable for any direct, 
# indirect, incidental, special, exemplary, or consequential damages
# (including but not limited to, procurement of substitute goods or 
# services; loss of use, data or profits; or business interruption)
# however caused and on any theory of liability, whether in contract,
# strict liability, or tort arising in any way out of the use of this 
# software.    
######################################################################

library("tools")     ## This is a base package
library("flowCore")  ## Tested with flowCore_1.42.2 
library("flowAI")    ## Tested with flowAI_1.4.4, flowAI_1.6.1, flowAI_1.6.2 and flowAI_1.7.1. (flowAI_1.7.0 is known to be broken)
library("png")       ## Tested with png_0.1-7, just to stitch PNG's together

## Last tested with R 3.4.1 (2017-06-30)
## Check what the user has and compare to what we know works
sessionInfo()

## For debugging to see what the parameter values are passed from FlowJo
# cat("FJ-DATA-FILE-PATH         = FJ_DATA_FILE_PATH \n")
# cat("FJ-CSV-OUPUT-FILE         = FJ_CSV_OUPUT_FILE \n")
# cat("FJ-PAR-REMOVE_FROM        = FJ_PAR_REMOVE_FROM \n")
# cat("FJ-PAR-SECOND-FRACTION-FR = FJ_PAR_SECOND_FRACTION_FR \n")
# cat("FJ-PAR-ALPHA-FR           = FJ_PAR_ALPHA_FR \n")
# cat("FJ-PAR-MAX-CPT-FS         = FJ_PAR_MAX_CPT_FS \n")
# cat("FJ-PAR-PEN-VALUE-FS       = FJ_PAR_PEN_VALUE_FS \n")
# cat("FJ-PAR-DECOMP-FR          = FJ_PAR_DECOMP_FR \n")
# cat("FJ-PAR-OUTLIER-FS         = FJ_PAR_OUTLIER_FS \n")
# cat("FJ-PAR-DELETE-WD          = FJ_PAR_DELETE_WD \n")
# cat("FJ-PAR-SIDE-FM            = FJ_PAR_SIDE_FM \n")

if ((compareVersion(as.character(packageVersion("flowAI")), "1.4.4") < 0) ||  ## flowAI version less than 1.4.4 is incompatible
	(compareVersion(as.character(packageVersion("flowAI")), "1.7.0") == 0)) { ## flowAI version 1.7.0 is broken
	fileConn<-file(paste0(tools::file_path_sans_ext("FJ_CSV_OUPUT_FILE"), ".err.txt"))
	errMsg <- paste0("Incompatible version of the flowAI R library found (", packageVersion("flowAI"), "); use flowAI 1.6.2 or another compatible version.")
	writeLines(errMsg, fileConn)
	close(fileConn)
	stop(errMsg, call.=FALSE)
}

robust.read.FCS <- function(fcsPath) {
  out <- tryCatch(
    {
	  read.FCS(fcsPath)
    }, 
	error=function(cond) {
      read.FCS(fcsPath, emptyValue=FALSE, ignore.text.offset=TRUE)
	})    
	return(out)
}

inputFCS <- robust.read.FCS("FJ_DATA_FILE_PATH");
eventsCount <- length(inputFCS@exprs[,1])

cleanUpAfterwards <- FJ_PAR_DELETE_WD
originalDir <- getwd()

pen_valueFS <- as.numeric("FJ_PAR_PEN_VALUE_FS")
if (is.na(pen_valueFS)) pen_valueFS <- "FJ_PAR_PEN_VALUE_FS";

parNames <- c(FJ_PARAMS_LIST)
# FlowJo sometimes gives us names like [V705-A] but the actual names in the FCS file are <V705-A>
# FlowJo also replaces '_' with '/' so let's try fix that as well
parNames <- unlist(lapply(parNames, function(name) {
	if (name %in% colnames(inputFCS)) {
		name
	} else {
		# Let's try [] to <>
		name2 <- gsub("[", "<", name, fixed=TRUE)
		name2 <- gsub("]", ">", name2, fixed=TRUE)
		if (name2 %in% colnames(inputFCS)) {
			name2 # Worked, return it
		} else {
			# Previous fix did not do it, _ => / on the original names
			name2 <- gsub("_", "/", name, fixed=TRUE)
			if (name2 %in% colnames(inputFCS)) {
				name2 # Worked, return it
			} else {
				# That did not work either, let's try both [] => on top of the previous fix (_ => /)
				name3 <- gsub("[", "<", name2, fixed=TRUE)
				name3 <- gsub("]", ">", name3, fixed=TRUE)
				if (name3 %in% colnames(inputFCS)) {
					name3 # Worked, finally, return it
				} else {
					stop(paste("The input FCS file does not contain the provided input parameters, missing", name), call.=FALSE)
				}
			}
		}
	}
}))

if (length(parNames) == 0)
	stop("The input FCS file does not contain the provided input parameters.", call.=FALSE)

setwd(dirname("FJ_CSV_OUPUT_FILE"))
subDir <- paste(tools::file_path_sans_ext(basename("FJ_CSV_OUPUT_FILE")), ".QC", sep="")

if (file.exists(subDir)) {
	setwd(file.path(getwd(), subDir))
} else {
	dir.create(file.path(getwd(), subDir))
	setwd(file.path(getwd(), subDir))
}

ChRemoveFS <- setdiff(colnames(inputFCS), parNames)
ChRemoveFS

newFlowFrame <- flow_auto_qc(
	inputFCS, 
	output = 2, 
	ChRemoveFS = ChRemoveFS, 
	remove_from = "FJ_PAR_REMOVE_FROM", 
	second_fractionFR = FJ_PAR_SECOND_FRACTION_FR,
	max_cptFS = FJ_PAR_MAX_CPT_FS,
	pen_valueFS = pen_valueFS,
	outlierFS = FJ_PAR_OUTLIER_FS,
	decompFR = FJ_PAR_DECOMP_FR,
	sideFM = "FJ_PAR_SIDE_FM",
	neg_valuesFM = 1,
	fcs_QC = FALSE,
	folder_results = FALSE,
	html_report = TRUE, ## We extract the figures from this
	alphaFR = FJ_PAR_ALPHA_FR)

# All good events will be set to 2000 +/- 1, all bad events to 6000 +/- 1. 
labels <- rep(2000, eventsCount) + runif(min=-1, max=1, n=eventsCount)
nbad <- length(which(newFlowFrame@exprs[,ncol(newFlowFrame)] > 10000))
labels[which(newFlowFrame@exprs[,ncol(newFlowFrame)] > 10000)] <- 6000 + runif(min=-1, max=1, n=nbad)

labels <- as.matrix(labels)
colnames(labels) <- c("flowAI")
write.csv(labels, file="FJ_CSV_OUPUT_FILE", row.names=FALSE)

## Here we take all the PNG files from the figure folder and merge those into a single PNG that the plugin will keep
subDir <- "figure"
if (file.exists(subDir)) {
	setwd(file.path(getwd(), subDir))
} else {
	dir.create(file.path(getwd(), subDir))
	setwd(file.path(getwd(), subDir))
}

qcImages <- list.files(pattern="*.png")
nImages <- length(qcImages)
if (nImages > 0) {
	imageInfo <- file.info(qcImages)
	## Sort images by size, the largest is the intensity over time for each channel, which we will give more room in the composed figure
	qcImages <- qcImages[match(1:length(qcImages),rank(imageInfo$size))]
	png(file=paste(tools::file_path_sans_ext("FJ_CSV_OUPUT_FILE"), ".png", sep=""), bg="transparent", width = 1500, height = 2000, units = "px")
	par(mar=rep(0,4)) ## No margins
	if (nImages == 3) layout(matrix(c(1,2,3,3), ncol=1, byrow=TRUE)) ## There should be 3 images, let's plot the last one twice as tall
	else layout(matrix(1:nImages, ncol=1, byrow=TRUE)) ## If not 3 images then just plot what's there (but it should not happen)
	for (i in 1:nImages) {
		img <- readPNG(qcImages[i])
		plot(NA, xlim=0:1, ylim=0:1, xaxt="n", yaxt="n", bty="n")
		rasterImage(img, 0, 0, 1, 1)
	}
	dev.off()	
}

setwd(dirname("FJ_CSV_OUPUT_FILE"))
#if (cleanUpAfterwards) {
#	subDir <- paste(tools::file_path_sans_ext(basename("FJ_CSV_OUPUT_FILE")), ".QC", sep="")
#	pathToDelete <- file.path(getwd(), subDir)
#	if (nchar(pathToDelete) > 10
#		## Extra check to make sure we aren't deleting at top level
#		&& (length(unlist(strsplit(pathToDelete, "\\\\"))) >= 3 || length(unlist(strsplit(pathToDelete, "/"))) >= 3)) {
#		cat(paste("Deleting directory", pathToDelete, "\n"))
#		unlink(subDir, recursive=TRUE)
#	} else {
#		cat(paste("Deleting directory", pathToDelete, "seems dangerous, so leaving it.\n")) 
#	}
#}

setwd(originalDir)

# R seems to be saving the .RData when exiting, so let's clean up to at least make that tiny (i.e., empty environment)
rm(list=ls())
