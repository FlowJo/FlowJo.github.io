////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2017 Josef Spidlen, Ph.D., FlowJo, LLC
//
// License
// The software is distributed under the terms of the 
// Artistic License 2.0
// http://www.r-project.org/Licenses/Artistic-2.0
// 
// Disclaimer
// This software and documentation come with no warranties of any kind.
// This software is provided "as is" and any express or implied 
// warranties, including, but not limited to, the implied warranties of
// merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the  copyright holder be liable for any direct, 
// indirect, incidental, special, exemplary, or consequential damages
// (including but not limited to, procurement of substitute goods or 
// services; loss of use, data or profits; or business interruption)
// however caused and on any theory of liability, whether in contract,
// strict liability, or tort arising in any way out of the use of this 
// software.    
//////////////////////////////////////////////////////////////////////////////

package com.flowjo.plugin.flowai;

import java.awt.Component;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import com.flowjo.plugin.flowai.utils.DoubleNumberFormatter;

import com.treestar.flowjo.engine.FEML;
import com.treestar.flowjo.engine.utility.R_Algorithm;
import com.treestar.lib.PluginHelper;
import com.treestar.lib.core.ExportFileTypes;
import com.treestar.lib.core.ExternalAlgorithmResults;
import com.treestar.lib.data.StringUtil;
import com.treestar.lib.gui.FJList;
import com.treestar.lib.gui.GuiFactory;
import com.treestar.lib.gui.HBox;
import com.treestar.lib.gui.numberfields.FJFormattedTextField;
import com.treestar.lib.gui.numberfields.RangedDoubleTextField;
import com.treestar.lib.gui.numberfields.RangedIntegerTextField;
import com.treestar.lib.gui.panels.FJLabel;
import com.treestar.lib.gui.swing.FJCheckBox;
import com.treestar.lib.gui.swing.FJComboBox;
import com.treestar.lib.xml.SElement;

public class FlowAI extends R_Algorithm {

	private static final String pluginVersion = "1.2";
	private static final String pluginName = "flowAI";
    private static final String foo = "foo";
    private static final String derParName = pluginName;
    public static final String One = "1";
    public static final String Zero = "0";
    public static final String True = "true";
    public static final String False = "false";    
	
    private FJComboBox fRemoveChecksCombo = new FJComboBox(removeChecksHuman);
    private FJComboBox fSideFMCombo = new FJComboBox(sideFMOptionsHuman);
    private RangedDoubleTextField parSecondFractionFRField = null;
    private RangedDoubleTextField parAlphaFRField = null;
    private RangedIntegerTextField parMaxCptFsField = null;
    private FJFormattedTextField parPenValueFsField = null;
    private FJCheckBox parDecompFRCheckbox = null;
    private FJCheckBox parOutlierFSCheckbox = null;
    private FJCheckBox parDeleteWDCheckbox = null;
    
    private static final int fixedLabelWidth   = 135;
    private static final int fixedFieldWidth   = 72;
    private static final int fixedLabelHeigth  = 25;
    private static final int fixedFieldHeigth  = 25;
    private static final int fixedComboWidth   = 300;
    private static final int fixedToolTipWidth = 400;
    private static final int hSpaceHeigth = 5;
    
    private static final String sLabelRemoveFrom       = "Anomalies to exclude";
    private static final String sLabelSecondFractionFR = "Second fraction FR";
    private static final String sLabelAlphaFR          = "Alpha FR";
    private static final String sLabelMaxCptFS         = "Maximum changepoints";
    private static final String sLabelPenValueFS       = "Changepoint penalty";
    private static final String sLabelDecompFR         = "Decompose flow rate";
    private static final String sLabelOutlierFS        = "Remove outliers";
    private static final String sLabelDeleteWD         = "Clean up working dir";
    private static final String sLabelSideFM           = "Dynamic range check side";
            
    private static final String sRemoveFromToolTip       = "Select which of the 3 possioble checks shall be used to filter good events (all checks will always be performed, but only those selected will be used to filter good events).";
    private static final String sSecondFractionFRToolTip = "The fraction of a second used to split the time channel to recreate the flow rate. You can set it to your FCS $TIMESTEP value if you wish to recreate the flow rate at the maximum resolution as acquired. Larger values will speed up the test.";
    private static final String sAlphaFRToolTip          = "The level of statistical significance to accept anomalies detected by the ESD (Extreme Studentized Deviate) method.";
    private static final String sMaxCptFsToolTip         = "The maximum number of changepoints that can be detected for each channel.";
    private static final String sPenValueFsToolTip       = "Penalty for the changepoint algorithm. This can be a numeric value or text giving a formula to use, e.g., 1.5*log(n), where n indicates the number of cells in the FCS file. The higher the penalty value the less strict is the detection of the anomalies.";
    private static final String sDecompFRToolTip         = "Indicating whether the flow rate should be decomposed in the trend and cyclical components. If checked then the ESD outlier detection will be executed on the trendcomponent penalized by the magnitude of the cyclical component. Otherwise, the ESD outlier detection will be executed on the original flow rate.";
    private static final String sOutlierFSToolTip        = "Indicating whether outliers should be removed before the changepoint detection of the signal acquisition check.";
    private static final String sDeleteWDToolRTip        = "Indication whether additional files (QC HTML reports and mini reports) should be cleaned up from the working directory after the plugin finishies.";
    private static final String sSideFMToolTip           = "Select whether the dynamic range check should be performed on both limits, just the upper limit or just the lower limit.";

    private static boolean fDecompFR = true, fOutlierFS = false, fDeleteWD = true;
    
    public static final String sOptionNameRemoveFrom       = "RemoveFrom";
    public static final String sOptionNameSecondFractionFR = "SecondFractionFR";
    public static final String sOptionNameAlphaFR          = "AlphaFR";
    public static final String sOptionNameMaxCptFs         = "MaxCptFS";
    public static final String sOptionNamePenValueFs       = "PenValueFs";
    public static final String sOptionNameDecompFR         = "DecompFR";
    public static final String sOptionNameOutlierFS        = "OutlierFS";
    public static final String sOptionNameDeleteWD         = "DeleteWD";
    public static final String sOptionNameSideFM           = "SideFM";
    
    private static final String channelsLabelLine1 = "FCS channels to be used by flowAI for the signal acquisition check.";
    private static final String channelsLabelLine2 = "Select multiple items by pressing the Shift key or toggle items by holding the Ctrl (or Cmd)";
    private static final String channelsLabelLine3 = "keys. The Time channel must exist in order for flowAI to be able to check the data set.";
    
    private static final String citingLabelLine1   = "If you are using flowAI, please cite our work as:";
    private static final String citingLabelLine2   = "Monaco G, Chen H, Poidinger M, Chen J, de Magalhães JP, Larbi A.:";
    private static final String citingLabelLine3   = "flowAI: automatic and interactive anomaly discerning tools for flow cytometry data.";
    private static final String citingLabelLine4   = "Bioinformatics. 2016 Aug 15; 32(16):2473-80. doi: 10.1093/bioinformatics/btw191";
    
    protected static final String sIconName = "images/flowAIIcon.png";
    private static Icon myIcon = null;
    
    // Note that the order of items in removeChecks must correspond to removeChecksHuman
    public static final String[] removeChecks = new String[] {"all", "FR_FS", "FR_FM", "FS_FM", "FR", "FS", "FM" };
    public static final String[] removeChecksHuman = new String[] {
    		"All checks", 
    		"Flow rate and signal acquisition", "Flow rate and dynamic range", "Signal acquisition and dynamic range",
    		"Flow rate only", "Signal acquisition only", "Dynamic range only" };
    
    // Note that the order of items in sideFMOptions must correspond to sideFMOptionsHuman
    public static final String[] sideFMOptionsHuman = new String[] { "Both", "Upper", "Lower" };
    public static final String[] sideFMOptions = new String[] { "both", "upper", "lower" };
    
    public FlowAI() 
	{
		super(pluginName);
	}

	public String getName() 
	{
		return(pluginName);
	}

	public String getVersion() 
	{
		return(pluginVersion);
	}
	
	@Override
    protected String getIconName()
    {
        return sIconName;
    }
	
	@Override
	protected boolean showClusterInputField()
	{
		return false;
	}
	
	@Override
	public ExportFileTypes useExportFileType() {
		return ExportFileTypes.FCS;
	}

	public ExternalAlgorithmResults invokeAlgorithm(SElement fcmlQueryElement, File sampleFile, File outputFolder) 
	{
        ExternalAlgorithmResults results = new ExternalAlgorithmResults();
        if(!sampleFile.exists()) 
        {
            results.setErrorMessage("Input file did not exist");
            return results;
        } 
        else
        {
            // Let's force recalculation all the time because it's relatively quick and we don't seem to handle
        	// checkUseExistingFiles well (i.e., if input settings change a bit, we still tend to return previous
        	// results instead of recalculating
        	// checkUseExistingFiles(fcmlQueryElement);
        	fUseExistingFiles = false;
        	
            String sampleName = StringUtil.rtrim(sampleFile.getName(), ".fcs");
            FlowAIRFlowCalc calculator = new FlowAIRFlowCalc();
            File fcsAIResult = calculator.performFlowAI(sampleFile, sampleName, preprocessCompParameterNames(), fOptions, outputFolder.getAbsolutePath(), useExistingFiles());
            calculator.deleteScriptFile();
            checkROutFile(calculator);
            
            // results.setCSVFile(fcsAIResult);
			// The above works but triggers additional clustering, which is not desirable, so the line below does a better job
			// Note that I am not producing any pops from this directly (Gating-ML is separate), but I will to give it
			// some name or else it does not work, thus the foo...
            if (fcsAIResult != null && fcsAIResult.exists()) {
            	PluginHelper.createClusterParameter(results, foo, fcsAIResult);
            	addGatingML(results);
            } else {
            	boolean errorSet = false;
                if (fcsAIResult != null) try {
                	String fcsAIResultPath = fcsAIResult.getAbsolutePath().toString();
                	fcsAIResultPath = fcsAIResultPath.substring(0, fcsAIResultPath.lastIndexOf('.'));
                	File errOutFile = new File(fcsAIResultPath + ".err.txt");
                	if (errOutFile != null && errOutFile.exists()) {
                		String error = readFile(errOutFile);
                		if (error != null && !error.isEmpty()) {
                			results.setErrorMessage(error);
                			errorSet = true;
                		}
                	}
    			}
    			catch (MalformedURLException e) { }
				catch (IOException e) { }
            	if (!errorSet) 
            		results.setErrorMessage("flowAI has failed to produce the expected derived parameter.");
            }
            
            try {
            	String fcsAIResultPath = fcsAIResult.getAbsolutePath().toString();
            	fcsAIResultPath = fcsAIResultPath.substring(0, fcsAIResultPath.lastIndexOf('.'));
            	File pngOutFile = new File(fcsAIResultPath + ".png");
            	if (pngOutFile != null && pngOutFile.exists())
            		results.setImageURL(pngOutFile.toURI().toURL());
			}
			catch (MalformedURLException e) { }

            return results;
        }
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	protected List<Component> getPromptComponents(SElement selement, List<String> list)
    {
        ArrayList<Component> componentList = new ArrayList<Component>();
        
        FJLabel fjLabel1 = new FJLabel(channelsLabelLine1);
        FJLabel fjLabel2 = new FJLabel(channelsLabelLine2);
        FJLabel fjLabel3 = new FJLabel(channelsLabelLine3);
        
        List<String> pNames = new ArrayList<String>();
		for (SElement pElem : selement.getChildren(FEML.Parameter))
			pNames.add(pElem.getString(FEML.name));
		if (pNames.isEmpty()) {
			// If empty it means this is the first time it is being invoked, so let's select the uncompensated pars but not time and not FSC and SSC
			for (String p : list) {
	    		// FlowJo's parameter names are often in the form of Name :: Description, we only want the Name part from that
	    		int parDescIndex = p.indexOf(" :: ");
	    		if(parDescIndex > 0) p = p.substring(0, parDescIndex);
				if (!p.toLowerCase().contains("comp") && 
					!p.toLowerCase().contains("time") && 
					!p.toLowerCase().startsWith("fs") && 
					!p.toLowerCase().startsWith("ss") ) {
					SElement pElem = new SElement(FEML.Parameter);
					pElem.setString(FEML.name, p);
					selement.addContent(pElem);
				}
			}
		}

        // fParameterNameList = new FJList(new DefaultListModel<Component>());
        // FlowJo advised against using DefaultListModel<Component>() due to compatibility issues. Following the advise...
        fParameterNameList = new FJList(new DefaultListModel());
        fParameterNameList.setSelectionMode(2);
        JScrollPane parListScrollPane = new JScrollPane(fParameterNameList);
        GuiFactory.setSizes(parListScrollPane, new Dimension(100, Math.min(200, list.size() * 20)));
        componentList.add(fjLabel1);
        componentList.add(fjLabel2);
        componentList.add(fjLabel3);
        componentList.add(parListScrollPane);
        
        // Default parameter values
        double parSecondFractionFR = 0.1;
        double parAlphaFR = 0.01; 
        int parMaxCptFs = 3;
        String parPenValueFs = "200"; // This is typically a number, but can also be a formula, like 5*log(n), thus keeping as string
        
        // If there are option set already (e.g., from the workspace), then
        // let's retrieve those and use them instead of defaults.
        Iterator<SElement> iterator = selement.getChildren("Option").iterator();
        int savedRemoveFromIndex = -1, savedSideFMIndex = -1;
        while(iterator.hasNext()) {
            SElement option = iterator.next();

            String savedRemoveFrom = option.getString(sOptionNameRemoveFrom);
        	int i = 0;
    		if (savedRemoveFrom != null && !savedRemoveFrom.isEmpty()) for (String s : FlowAI.removeChecks) {
    			if (s.equals(savedRemoveFrom)) { 
    				savedRemoveFromIndex = i;
    				continue;
    			}
    			i++;
    		}
        	String savedSideFM = option.getString(sOptionNameSideFM);
        	i = 0;
    		if (savedSideFM != null && !savedSideFM.isEmpty()) for (String s : FlowAI.sideFMOptions) {
    			if (s.equals(savedSideFM)) { 
    				savedSideFMIndex = i;
    				continue;
    			}
    			i++;
    		}
            double savedSecondFractionFR = option.getDouble(sOptionNameSecondFractionFR, -1);
            if (savedSecondFractionFR > 0 && savedSecondFractionFR <= 1) parSecondFractionFR = savedSecondFractionFR;
            double savedAlphaFR = option.getDouble(sOptionNameAlphaFR, -1);
            if (savedAlphaFR > 0 && savedAlphaFR <= 1) parAlphaFR = savedAlphaFR;
            int savedParMaxCptFs = option.getInt(sOptionNameMaxCptFs, -1);
            if (savedParMaxCptFs > 0 && savedParMaxCptFs <= 100) parMaxCptFs = savedParMaxCptFs;
            
            String savedDecompFR = option.getAttributeValue(sOptionNameDecompFR);
    		if (savedDecompFR != null)
    			fDecompFR = One.equals(savedDecompFR) || True.equals(savedDecompFR);
            String savedOutlierFS = option.getAttributeValue(sOptionNameOutlierFS);
    		if (savedOutlierFS != null)
    			fOutlierFS = One.equals(savedOutlierFS) || True.equals(savedOutlierFS);
            String savedDeleteWD = option.getAttributeValue(sOptionNameDeleteWD);
    		if (savedDeleteWD != null)
    			fDeleteWD = One.equals(savedDeleteWD) || True.equals(savedDeleteWD);

    		String savedPenValueFs = option.getString(sOptionNamePenValueFs);
            if (savedPenValueFs != null && !savedPenValueFs.isEmpty()) parPenValueFs = savedPenValueFs;
        }
		if (savedRemoveFromIndex >= 0 && savedRemoveFromIndex < fRemoveChecksCombo.getItemCount())
			fRemoveChecksCombo.setSelectedIndex(savedRemoveFromIndex);
		if (savedSideFMIndex >= 0 && savedSideFMIndex < fSideFMCombo.getItemCount())
			fSideFMCombo.setSelectedIndex(savedSideFMIndex);

		FJLabel hSpaceLabels[] = new FJLabel[6];
		for (FJLabel hSpaceLabel : hSpaceLabels) {
	        hSpaceLabel = new FJLabel("");
	        GuiFactory.setSizes(hSpaceLabel, new Dimension(fixedLabelWidth, hSpaceHeigth));			
		}
		
        FJLabel LabelRemoveFrom = new FJLabel(sLabelRemoveFrom);
        fRemoveChecksCombo.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sRemoveFromToolTip + "</p></html>");
        GuiFactory.setSizes(fRemoveChecksCombo, new Dimension(fixedComboWidth, fixedFieldHeigth));
        GuiFactory.setSizes(LabelRemoveFrom, new Dimension(fixedLabelWidth, fixedLabelHeigth));
        HBox hboxRemoveFrom = new HBox(new Component[] { LabelRemoveFrom, fRemoveChecksCombo });        
        
        FJLabel labelSecondFractionFR = new FJLabel(sLabelSecondFractionFR);
        parSecondFractionFRField = new RangedDoubleTextField(0.0, 1.0, new DoubleNumberFormatter());
        parSecondFractionFRField.setDouble(parSecondFractionFR);
        parSecondFractionFRField.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sSecondFractionFRToolTip + "</p></html>");
        GuiFactory.setSizes(parSecondFractionFRField, new Dimension(fixedFieldWidth, fixedFieldHeigth));
        GuiFactory.setSizes(labelSecondFractionFR, new Dimension(fixedLabelWidth, fixedLabelHeigth));
        
        FJLabel labelAlphaFR = new FJLabel(sLabelAlphaFR);
        labelAlphaFR.setHorizontalAlignment(SwingConstants.RIGHT);
        parAlphaFRField = new RangedDoubleTextField(0.0, 1.0, new DoubleNumberFormatter());
        parAlphaFRField.setDouble(parAlphaFR);
        parAlphaFRField.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sAlphaFRToolTip + "</p></html>");
        GuiFactory.setSizes(parAlphaFRField, new Dimension(fixedFieldWidth, fixedFieldHeigth));
        GuiFactory.setSizes(labelAlphaFR, new Dimension(fixedLabelWidth, fixedLabelHeigth));

        FJLabel labelMaxCptFs = new FJLabel(sLabelMaxCptFS);
        parMaxCptFsField = new RangedIntegerTextField(1, 100);
        parMaxCptFsField.setInt(parMaxCptFs);
        parMaxCptFsField.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sMaxCptFsToolTip + "</p></html>");
        GuiFactory.setSizes(parMaxCptFsField, new Dimension(fixedFieldWidth, fixedFieldHeigth));
        GuiFactory.setSizes(labelMaxCptFs, new Dimension(fixedLabelWidth, fixedLabelHeigth));
        
        FJLabel labelPenValueFs = new FJLabel(sLabelPenValueFS);
        labelPenValueFs.setHorizontalAlignment(SwingConstants.RIGHT);
        parPenValueFsField = new FJFormattedTextField();
        parPenValueFsField.setHorizontalAlignment(SwingConstants.RIGHT);
        parPenValueFsField.setText(parPenValueFs);
        parPenValueFsField.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sPenValueFsToolTip + "</p></html>");
        GuiFactory.setSizes(parPenValueFsField, new Dimension(fixedFieldWidth, fixedFieldHeigth));
        GuiFactory.setSizes(labelPenValueFs, new Dimension(fixedLabelWidth, fixedLabelHeigth));
        
        FJLabel LabelSideFM = new FJLabel(sLabelSideFM);
        fSideFMCombo.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sSideFMToolTip + "</p></html>");
        GuiFactory.setSizes(fSideFMCombo, new Dimension(fixedComboWidth, fixedFieldHeigth));
        GuiFactory.setSizes(LabelSideFM, new Dimension(fixedLabelWidth, fixedLabelHeigth));
        HBox hboxSideFM = new HBox(new Component[] { LabelSideFM, fSideFMCombo });
        
        parDecompFRCheckbox = new FJCheckBox(sLabelDecompFR);
        parDecompFRCheckbox.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sDecompFRToolTip + "</p></html>");
        parDecompFRCheckbox.setSelected(fDecompFR);
        parOutlierFSCheckbox = new FJCheckBox(sLabelOutlierFS);
        parOutlierFSCheckbox.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sOutlierFSToolTip + "</p></html>");
        parOutlierFSCheckbox.setSelected(fOutlierFS);
        parDeleteWDCheckbox = new FJCheckBox(sLabelDeleteWD);
        parDeleteWDCheckbox.setToolTipText("<html><p width=\"" + fixedToolTipWidth + "\">" + sDeleteWDToolRTip + "</p></html>");        
        parDeleteWDCheckbox.setSelected(fDeleteWD);
        HBox hboxCheckBoxes = new HBox(new Component[] { parDecompFRCheckbox, parOutlierFSCheckbox, parDeleteWDCheckbox });
        
        componentList.add(hSpaceLabels[0]);
        componentList.add(hboxRemoveFrom);

        componentList.add(hSpaceLabels[1]);
        HBox hboxSecFrAndAlphaFR = new HBox(new Component[] { labelSecondFractionFR, parSecondFractionFRField, labelAlphaFR, parAlphaFRField });
        componentList.add(hboxSecFrAndAlphaFR);
        
        componentList.add(hSpaceLabels[2]);
        HBox hboxMaxCptFsAndPenValueFs = new HBox(new Component[] { labelMaxCptFs, parMaxCptFsField, labelPenValueFs, parPenValueFsField });
        componentList.add(hboxMaxCptFsAndPenValueFs);
        
        componentList.add(hSpaceLabels[3]);
        componentList.add(hboxSideFM);

        componentList.add(hSpaceLabels[4]);
        componentList.add(hboxCheckBoxes);

        fShowOutputCheckBox = new FJCheckBox("Save the R script and output messages");
        fShowOutputCheckBox.setToolTipText("Keep a file that shows execution of the script");
        fShowOutputCheckBox.setSelected(fShowOutput);
    	componentList.add(new HBox(new Component[] { fShowOutputCheckBox }));
    	
		if (!fRoutFile.isEmpty())
			componentList.add(new HBox(Box.createHorizontalGlue(),  createShowOutputButton(), Box.createHorizontalGlue()));

        componentList.add(hSpaceLabels[5]);
        componentList.add(new FJLabel(citingLabelLine1));
        componentList.add(new FJLabel(citingLabelLine2));
        componentList.add(new FJLabel(citingLabelLine3));
        componentList.add(new FJLabel(citingLabelLine4));
        
        return componentList;
    }
    
	@SuppressWarnings("deprecation")
	@Override
    protected void extractPromptOptions()
    {
    	fOptions = new HashMap<String, String>();
    	fParameterNames = new ArrayList<String>();

    	boolean timeParameterSelected = false;
    	// for (Object obj : fParameterNameList.getSelectedValuesList())
    	// FlowJo advised against using getSelectedValuesList() due to compatibility issues. Following the advise...
    	for (Object obj : fParameterNameList.getSelectedValues()) 
    	{
    		String parName = (new StringBuilder()).append("").append(obj).toString();
    		// FlowJo's parameter names are often in the form of Name :: Description, we only want the Name part from that
    		int parDescIndex = parName.indexOf(" :: ");
    		if(parDescIndex > 0) parName = parName.substring(0, parDescIndex);
    		if(parName.compareToIgnoreCase("Time") == 0) timeParameterSelected = true;
    		fParameterNames.add(parName);
    	}
    	// We really need the Time parameter, so we select it even if the user doesn't.
    	if(!timeParameterSelected) fParameterNames.add("Time");
    	
    	// Save all the flowAI specific options
    	if (fRemoveChecksCombo.getSelectedIndex() < removeChecks.length)
    		fOptions.put(sOptionNameRemoveFrom, removeChecks[fRemoveChecksCombo.getSelectedIndex()]);
    	else 
    		fOptions.put(sOptionNameRemoveFrom, removeChecks[0]);
    	
    	if (fSideFMCombo.getSelectedIndex() < sideFMOptions.length)
    		fOptions.put(sOptionNameSideFM, sideFMOptions[fSideFMCombo.getSelectedIndex()]);
    	else
    		fOptions.put(sOptionNameSideFM, sideFMOptions[0]);
    	
        fOptions.put(sOptionNameSecondFractionFR, Double.toString(parSecondFractionFRField.getDouble()));
        fOptions.put(sOptionNameAlphaFR, Double.toString(parAlphaFRField.getDouble()));
        fOptions.put(sOptionNameMaxCptFs, Double.toString(parMaxCptFsField.getInt()));
        fOptions.put(sOptionNamePenValueFs, sanitize(parPenValueFsField.getText()));
        fOptions.put(sOptionNameDecompFR, parDecompFRCheckbox.isSelected() ? One : Zero);
        fOptions.put(sOptionNameOutlierFS, parOutlierFSCheckbox.isSelected() ? One : Zero);
        fOptions.put(sOptionNameDeleteWD, parDeleteWDCheckbox.isSelected() ? One : Zero);
 
        fShowOutput = fShowOutputCheckBox.isSelected();
    }
	
	private String sanitize(String text)
	{
		if (text == null || text.isEmpty())
			return "";
		else 
			return text.
					replaceAll(" ", "_").
					replaceAll("<", "_").
					replaceAll(">", "_").
					replaceAll("&", "_").
					replaceAll("\"", "_");
	}

	private void addGatingML(ExternalAlgorithmResults results)
	{
		// Gate on the "flowAI" parameter
		// All good events are 2000, all bad events are 6000 
		
		SElement gate = new SElement("gating:Gating-ML");
		
		SElement goodEventsGate = new SElement("gating:RectangleGate");
		goodEventsGate.setString("gating:id", "GoodEvents");
		gate.addContent(goodEventsGate);
		SElement dimElem1 = new SElement("gating:dimension");
		dimElem1.setDouble("gating:min", 1500);
		dimElem1.setDouble("gating:max", 2500);
		goodEventsGate.addContent(dimElem1);
		SElement fcsDimElem1 = new SElement("data-type:fcs-dimension");
		fcsDimElem1.setString("data-type:name", derParName);
		dimElem1.addContent(fcsDimElem1);

		SElement badEventsGate = new SElement("gating:RectangleGate");
		badEventsGate.setString("gating:id", "BadEvents");
		gate.addContent(badEventsGate);
		SElement dimElem2 = new SElement("gating:dimension");
		dimElem2.setDouble("gating:min", 5500);
		dimElem2.setDouble("gating:max", 6500);
		badEventsGate.addContent(dimElem2);
		SElement fcsDimElem2 = new SElement("data-type:fcs-dimension");
		fcsDimElem2.setString("data-type:name", derParName);
		dimElem2.addContent(fcsDimElem2);

		results.setGatingML(gate.toString());
	}
	
	@Override
	public Icon getIcon()
	{
		if (myIcon == null)
		{
			URL url = getClass().getClassLoader().getResource(sIconName);
			if (url != null)
				myIcon = new ImageIcon(url);
		}
		return myIcon;
	}

	private String readFile(File file) throws IOException
	{
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = null;
		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");
		try {
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}
			return stringBuilder.toString();
		}
		finally {
			reader.close();
		}
	}
}
