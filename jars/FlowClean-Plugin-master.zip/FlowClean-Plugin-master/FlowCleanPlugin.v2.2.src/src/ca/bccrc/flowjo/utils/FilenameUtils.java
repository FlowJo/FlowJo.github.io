package ca.bccrc.flowjo.utils;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import ca.bccrc.flowjo.FlowClean;

public abstract class FilenameUtils {

	public static String fixFileNamePart(String fileName) {
		return fileName.
			replaceAll(" ", "_").replaceAll("/", "_").replaceAll("\\\\", "_").
	        replaceAll("\\:", "_").replaceAll("\\*", "_").replaceAll("\\?", "_").
	        replaceAll("\"", "_").replaceAll("\\|", "_");
	}
	
	public static String createOutputFolderPath(String prefix, String sampleName, List<String> parameterNames, Map<String, String> options) {
		
		// This method needs to capture the sampleName as well as other input
		// of the flowClean algorithm so that results caching works properly
        String outFolder = System.getProperty("java.io.tmpdir");
        String fileSep = System.getProperty("file.separator");
        if(!outFolder.endsWith("/") && !outFolder.endsWith("\\")) 
        	outFolder = (new StringBuilder()).append(outFolder).append(fileSep).toString();
        
        Collections.sort(parameterNames);
        String parametersString = "";
        boolean first = true;
        for (String s : parameterNames)
        {
        	if(first) parametersString += s;
        	else parametersString += "_" + s;
        	first = false;
        }
        parametersString = fixFileNamePart(parametersString);
        
        outFolder = (new StringBuilder()).append(outFolder).
        	append(prefix).append(fileSep).
        	append(fixFileNamePart(sampleName)).append(fileSep).
        	append(options.get(FlowClean.sOptionNameBinSize)).append("_").
        	append(options.get(FlowClean.sOptionNameCellCutoff)).append("_").
        	append(options.get(FlowClean.sOptionNameCutoff)).append("_").
        	append(options.get(FlowClean.sOptionNameMaxFc)).append(fileSep).
        	append(parametersString).append(fileSep).
        	toString().replaceAll(" ", "_");
        
        new File(outFolder).mkdirs();
        return outFolder;
	}

}
