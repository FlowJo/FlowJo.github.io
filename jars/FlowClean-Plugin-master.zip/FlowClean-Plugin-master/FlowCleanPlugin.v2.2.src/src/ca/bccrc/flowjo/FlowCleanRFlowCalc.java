////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2015 Josef Spidlen, Ph.D.
//
// License
// The software is distributed under the terms of the 
// Artistic License 2.0
// http://www.r-project.org/Licenses/Artistic-2.0
// 
// Disclaimer
// This software and documentation come with no warranties of any kind.
// This software is provided "as is" and any express or implied 
// warranties, including, but not limited to, the implied warranties of
// merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the  copyright holder be liable for any direct, 
// indirect, incidental, special, exemplary, or consequential damages
// (including but not limited to, procurement of substitute goods or 
// services; loss of use, data or profits; or business interruption)
// however caused and on any theory of liability, whether in contract,
// strict liability, or tort arising in any way out of the use of this 
// software.    
//////////////////////////////////////////////////////////////////////////////

package ca.bccrc.flowjo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URI;
import java.util.List;
import java.util.Map;

import com.treestar.lib.file.FileUtil;
import com.treestar.flowjo.engine.EngineManager;
import com.treestar.flowjo.engine.utility.RFlowCalculator;

import ca.bccrc.flowjo.utils.FilenameUtils;

public class FlowCleanRFlowCalc extends RFlowCalculator {
	
	// The path to the flowClean R script template from within the jar file
	private final static String flowCleanTemplatePath = "r/RScript.flowClean.Template.R";
	
	public File performFCSClean(File sampleFile, String sampleName, List<String> parameterNames, Map<String, String> options, String outputFolderPath, boolean useExistingFiles)
    {
		sampleName = sampleName.replaceAll(".ExtNode", "").replaceAll(".fcs", "").replaceAll(".LMD", "").trim();

		// We will look at flowClean.ini in the plugins directory, and if that exists and contains a line like
		// own_output_folder=true
		// then we will rewrite the outputFolderPath with our own path. 
		// Otherwise, we will use what FlowJo is giving us.
		try {
			String pluginsFolder = new File(new URI(FlowCleanRFlowCalc.class.getProtectionDomain().getCodeSource().getLocation().getPath()).getPath()).getParent();
			File flowCleanSettingsFile = new File(pluginsFolder, "flowClean.ini");
			BufferedReader br = new BufferedReader(new FileReader(flowCleanSettingsFile));
			String fileLine;
			while ((fileLine = br.readLine()) != null) {
				if (fileLine.startsWith("own_output_folder") && fileLine.endsWith("true")) {
					outputFolderPath = FilenameUtils.createOutputFolderPath("flowCleanFJ", sampleName, parameterNames, options);					
				}
		    }
			if (br != null) br.close();
		} catch (Exception ex) {}
		
        File outputFolder = new File(outputFolderPath);
        StringWriter scriptWriter = new StringWriter();
        File flowCleanScript = composeRFCSCleanStatements(sampleFile, sampleName, parameterNames, options, outputFolder, scriptWriter);
        if(flowCleanScript == null) return null;
        if(useExistingFiles && flowCleanScript.exists()) return flowCleanScript;
        
        String scriptFileName = (new StringBuilder()).append("RScript.flowClean.").append(System.currentTimeMillis()).append(".R").toString().replaceAll(" ", "_");
        try
        {
            fScriptFile = new File(outputFolderPath, scriptFileName);
            FileUtil.write(fScriptFile, scriptWriter.toString());
            executeRBatch(scriptFileName);
        }
        catch(Exception e) 
        {
            e.printStackTrace();
        }
        return flowCleanScript;
    }

	protected File composeRFCSCleanStatements(File sampleFile, String sampleName, List<String> parameterNames, Map<String, String> options, File outputFolder, StringWriter scriptWriter)
    {
        InputStream scriptStream = FlowCleanRFlowCalc.class.getResourceAsStream(flowCleanTemplatePath);
        
        String outFileName = (new StringBuilder()).append(FilenameUtils.fixFileNamePart(sampleName)).append(".flowClean").append(".csv").toString();
        if(outputFolder == null) outputFolder = sampleFile.getParentFile();
        
        File outFile = new File(outputFolder, outFileName);
        outFileName = outFile.getAbsolutePath();
        String dataFilePath = sampleFile.getAbsolutePath();
        // This is how FlowJo's flowMeans code is doing it; I just hope they tested it properly :-)
        if(EngineManager.isWindows()) outFileName = outFileName.replaceAll("\\\\", "/");
        if(EngineManager.isWindows()) dataFilePath = dataFilePath.replaceAll("\\\\", "/");
        
        String sParBinSize = options.get(FlowClean.sOptionNameBinSize);
        String sParCellCutoff = options.get(FlowClean.sOptionNameCellCutoff);
        String sParCutoff = options.get(FlowClean.sOptionNameCutoff);
        String sParMaxFc = options.get(FlowClean.sOptionNameMaxFc);
        try {
        	if(Double.parseDouble(sParCutoff) < Double.MIN_NORMAL) sParCutoff = "0.5";
        } catch (Exception e) {
        	sParCutoff = "0.5";
        }

        BufferedReader rTemplateReader = null;
        try {
			rTemplateReader = new BufferedReader(new InputStreamReader(scriptStream));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
        
        String scriptLine;
        try {
			while((scriptLine = rTemplateReader.readLine()) != null) 
			{
			    scriptLine = scriptLine.replaceAll("FJ_DATA_FILE_PATH", dataFilePath);
			    scriptLine = scriptLine.replaceAll("FJ_CSV_OUPUT_FILE", outFileName);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_BIN_SIZE", sParBinSize);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_CELL_CUTOFF", sParCellCutoff);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_CUTOFF", sParCutoff);
			    scriptLine = scriptLine.replaceAll("FJ_PAR_MAX_FC", sParMaxFc);
			    
			    if(scriptLine.contains("FJ_PARAMS_LIST")) {
			    	String parListStr = "";
			    	for (String parName : parameterNames)
			    	{
			    		// Note that we don't want the TIME parameter to be in the parameter list given to the R script, 
			    		// but we would like the TIME parameter to be present in the FCS file.
			    		if(parName.compareToIgnoreCase("TIME") != 0) {
			    			if(!parListStr.isEmpty()) parListStr = (new StringBuilder()).append(parListStr).append(",").toString();
			    			parListStr = (new StringBuilder()).append(parListStr).append("\"").append(parName).append("\"").toString();
			    		}
			    		// System.out.println(parName);
			    	}
			    	// System.out.println("parListStr = " + parListStr);
			    	scriptLine = scriptLine.replaceAll("FJ_PARAMS_LIST", parListStr);
			    }
			    
			    scriptWriter.append(scriptLine).append('\n');

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        if(rTemplateReader != null) {
        	try { rTemplateReader.close(); }
        	catch (Exception e) { e.printStackTrace(); }
        }
        
        return outFile;
    }

}
