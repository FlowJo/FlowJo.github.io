#######################################################################
# Copyright (c) 2015-2017 Josef Spidlen, Ph.D. and FlowJo, LLC
#
# License
# The software is distributed under the terms of the 
# Artistic License 2.0
# http://www.r-project.org/Licenses/Artistic-2.0
# 
# Disclaimer
# This software and documentation come with no warranties of any kind.
# This software is provided "as is" and any express or implied 
# warranties, including, but not limited to, the implied warranties of
# merchantability and fitness for a particular purpose are disclaimed.
# In no event shall the  copyright holder be liable for any direct, 
# indirect, incidental, special, exemplary, or consequential damages
# (including but not limited to, procurement of substitute goods or 
# services; loss of use, data or profits; or business interruption)
# however caused and on any theory of liability, whether in contract,
# strict liability, or tort arising in any way out of the use of this 
# software.
######################################################################

library("flowCore")
library("flowClean")
sessionInfo()

## For debugging to see what the parameter values are passed from FlowJo
# cat("FJ-DATA-FILE-PATH  = FJ_DATA_FILE_PATH \n")
# cat("FJ-CSV-OUPUT-FILE  = FJ_CSV_OUPUT_FILE \n")
# cat("FJ-PARAMS-LIST     = FJ_PARAMS_LIST \n")
# cat("FJ-PAR-BIN-SIZE    = FJ_PAR_BIN_SIZE \n")
# cat("FJ-PAR-CELL-CUTOFF = FJ_PAR_CELL_CUTOFF \n")
# cat("FJ-PAR-CUTOFF      = FJ_PAR_CUTOFF \n")
# cat("FJ-PAR-MAX-FC      = FJ_PAR_MAX_FC \n")

dataset <- 1

robust.read.FCS <- function(fcsPath) {
	out <- tryCatch(
			{
				read.FCS(fcsPath, dataset=dataset)
			}, 
			error=function(cond) {
				read.FCS(fcsPath, dataset=dataset, emptyValue=FALSE, ignore.text.offset=TRUE)
			})
	timeIndex <- -1
	timeIndex <- tryCatch(
			{
				match("time", tolower(colnames(out)))
			}, 
			error=function(cond) {
				-1				
			})
	if (!(is.na(timeIndex)) && (timeIndex > 0) && (min(exprs(out)[,timeIndex]) == max(exprs(out)[,timeIndex]))) {
		## Our time has a single value, that may be because there is a wrong $PnR, so let's make flowCore ignore it
		out <- tryCatch(
				{
					read.FCS(fcsPath, dataset=dataset, truncate_max_range = FALSE)
				}, 
				error=function(cond) {
					read.FCS(fcsPath, dataset=dataset, truncate_max_range = FALSE, emptyValue=FALSE, ignore.text.offset=TRUE)
				})
	}
	
	return(out)
}

inputFCS <- robust.read.FCS("FJ_DATA_FILE_PATH");
eventsCount <- length(inputFCS@exprs[,1])

parNames <- c(FJ_PARAMS_LIST)

if (length(parNames) == 0)
	stop("Some input parameters need to be selected!", call.=FALSE)

# FlowJo sometimes gives us names like [V705-A] but the actual names in the FCS file are <V705-A>
# FlowJo also replaces '_' with '/' so let's try fix that as well
parNames <- unlist(lapply(parNames, function(name) {
	if (name %in% colnames(inputFCS)) {
		name
	} else {
		# Let's try [] to <>
		name2 <- gsub("[", "<", name, fixed=TRUE)
		name2 <- gsub("]", ">", name2, fixed=TRUE)
		if (name2 %in% colnames(inputFCS)) {
			name2 # Worked, return it
		} else {
			# Previous fix did not do it, _ => / on the original names
			name2 <- gsub("_", "/", name, fixed=TRUE)
			if (name2 %in% colnames(inputFCS)) {
				name2 # Worked, return it
			} else {
				# That did not work either, let's try both [] => on top of the previous fix (_ => /)
				name3 <- gsub("[", "<", name2, fixed=TRUE)
				name3 <- gsub("]", ">", name3, fixed=TRUE)
				if (name3 %in% colnames(inputFCS)) {
					name3 # Worked, finally, return it
				} else {
					## Maybe we read a wrong dataset?
					cat(paste("The input FCS file does not contain the provided input parameter, missing", name, "\n"))
					"TRYDIFFERENTDATASET"
				}
			}
		}
	}
}))

## DEBUG info

inputFCS

parNames

eventsCount

if (length(parNames) == 0 || "TRYDIFFERENTDATASET" %in% colnames(inputFCS) || !("time" %in% tolower(colnames(inputFCS))))
{
	## Maybe we read the wrong dataset? Let's try the second one
	inputFCS <- new("flowFrame")
	dataset <- 2
	inputFCS <- robust.read.FCS("FJ_DATA_FILE_PATH");
	eventsCount <- length(inputFCS@exprs[,1])
	parNames <- c(FJ_PARAMS_LIST)
	
	parNames <- unlist(lapply(parNames, function(name) {
		if (name %in% colnames(inputFCS)) {
			name
		} else {
			# Let's try [] to <>
			name2 <- gsub("[", "<", name, fixed=TRUE)
			name2 <- gsub("]", ">", name2, fixed=TRUE)
			if (name2 %in% colnames(inputFCS)) {
				name2 # Worked, return it
			} else {
				# Previous fix did not do it, _ => / on the original names
				name2 <- gsub("_", "/", name, fixed=TRUE)
				if (name2 %in% colnames(inputFCS)) {
					name2 # Worked, return it
				} else {
					# That did not work either, let's try both [] => on top of the previous fix (_ => /)
					name3 <- gsub("[", "<", name2, fixed=TRUE)
					name3 <- gsub("]", ">", name3, fixed=TRUE)
					if (name3 %in% colnames(inputFCS)) {
						name3 # Worked, finally, return it
					} else {
						stop(paste("The input FCS file does not contain the provided input parameters, missing", name), call.=FALSE)
					}
				}
			}
		}
	}))
}

## DEBUG info

inputFCS

parNames

eventsCount

dataset

range(inputFCS, "data")

if (eventsCount == 0)
	stop("R failed to read the input FCS file.", call.=FALSE)

if (!("time" %in% tolower(colnames(inputFCS))))
	stop("The input FCS file does not contain the TIME parameter.", call.=FALSE)

if (length(parNames) == 0)
	stop("The input FCS file does not contain the provided input parameters.", call.=FALSE)

cleanedflowFrame <- clean(
    fF = inputFCS,
    vectMarkers = parNames,
    filePrefixWithDir = "tmp",
    ext = "fcs",
    binSize = FJ_PAR_BIN_SIZE,
    nCellCutoff = FJ_PAR_CELL_CUTOFF,
    cutoff = FJ_PAR_CUTOFF,
    fcMax = FJ_PAR_MAX_FC,
    announce = TRUE, 
    diagnostic = FALSE
)

# Giving FlowJo the labels directly does not seem to produce the desired results
# in FlowJo. Therefore, all good events will be set to 2000, all bad events to 6000. 
labels <- rep(2000, eventsCount) + runif(min=-1, max=1, n=eventsCount)
nbad <- length(which(cleanedflowFrame@exprs[,'GoodVsBad'] > 10000))
labels[which(cleanedflowFrame@exprs[,'GoodVsBad'] > 10000)] <- 6000 + runif(min=-1, max=1, n=nbad)

labels <- as.matrix(labels)
colnames(labels) <- c("flowClean")
write.csv(labels, file="FJ_CSV_OUPUT_FILE", row.names=FALSE)
