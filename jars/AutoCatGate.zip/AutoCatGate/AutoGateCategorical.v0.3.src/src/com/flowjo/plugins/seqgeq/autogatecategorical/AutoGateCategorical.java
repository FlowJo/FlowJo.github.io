/**
 * @author: Josef Spidlen, Ph.D.
 * 
 * Copyright 2017 FlowJo, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.flowjo.plugins.seqgeq.autogatecategorical;

import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;

import com.flowjo.lib.parameters.ParameterSelectionPanel;
import com.flowjo.lib.parameters.ParameterSelectionPanel.eParameterSelectionMode;
import com.flowjo.lib.parameters.ParameterSetMgrInterface;
import com.treestar.lib.PluginHelper;
import com.treestar.lib.core.ExportFileTypes;
import com.treestar.lib.core.ExternalAlgorithmResults;
import com.treestar.lib.core.PopulationPluginInterface;
import com.treestar.lib.core.SeqGeqExternalAlgorithmResults;
import com.treestar.lib.gui.GuiFactory;
import com.treestar.lib.gui.HBox;
import com.treestar.lib.gui.panels.FJLabel;
import com.treestar.lib.xml.SElement;

public class AutoGateCategorical implements PopulationPluginInterface
{

	private static final String gVersion = "0.3";
	private static final String gName = "Autogate categorical parameters";
	
	private List<String> parameterNames = new ArrayList<String>();
	private ExportFileTypes fileType = ExportFileTypes.CSV_PIR_SCALE;
	private String namePrefix = "";
	
	private static final double epsilon = 0.1;
	private static final int maxCats = 500;
	
	private static Icon myIcon = null;

	@Override
	public String getName()
	{
		return gName;
	}

	@Override
	public SElement getElement()
	{
		SElement result = new SElement(getClass().getName());
		if (!parameterNames.isEmpty())
		{
			SElement elem = new SElement("Parameters");
			result.addContent(elem);
			for (String pName : parameterNames)
			{
				SElement e = new SElement("P");
				e.setString("name", pName);
				elem.addContent(e);
			}
		}
		result.setString("namePrefix", namePrefix);
		return result;
	}

	@Override
	public void setElement(SElement element)
	{
		SElement params = element.getChild("Parameters");
		if (params == null)
			return;
		parameterNames.clear();
		for (SElement elem : params.getChildren())
		{
			parameterNames.add(elem.getString("name"));
		}
		namePrefix = element.getString("namePrefix");
	}

	@Override
	public List<String> getParameters()
	{
		return parameterNames;
	}

	@Override
	public Icon getIcon()
	{
		if (myIcon == null)
		{
			URL url = getClass().getClassLoader().getResource("images/AutoGateCatIcon.png");
			if (url != null)
				myIcon = new ImageIcon(url);
		}
		return myIcon;
	}

	@Override
	public ExportFileTypes useExportFileType()
	{
		return fileType;
	}

	@Override
	public String getVersion()
	{
		return gVersion;
	}
	
	@Override
	public boolean promptForOptions(SElement fcmlQueryElement, List<String> pNames)
	{

		// Use a helper method to get a ParameterSetMgrInterface, used by ParameterSelectionPanel
		ParameterSetMgrInterface mgr = PluginHelper.getParameterSetMgr(fcmlQueryElement);
		if (mgr == null)
			return false;

		List<Object> guiObjects = new ArrayList<Object>();
		FJLabel explainText = new FJLabel();
		guiObjects.add(explainText);
		String text = "<html><body>";
		text += "This plugin creates sub-populations based on a selected categorical parameter";
		text += "</body></html>";
		explainText.setText(text);

		ParameterSelectionPanel pane = new ParameterSelectionPanel(mgr, eParameterSelectionMode.WithSetsAndParameters, false, false, false, false);
		Dimension dim = new Dimension(300, 500);
		pane.setMaximumSize(dim);
		pane.setMinimumSize(dim);
		pane.setPreferredSize(dim);

		pane.setSelectedParameters(parameterNames);
		parameterNames.clear();
		guiObjects.add(pane);
		
		FJLabel label = new FJLabel("Name for new populations (optional)");
		String tip = "Population names will be created from this name or from the name of the selected parameter ";
		label.setToolTipText(tip);
		JFormattedTextField namePrefixInputField = new JFormattedTextField();
		namePrefixInputField.setText(namePrefix);
		namePrefixInputField.setToolTipText(tip);;
    	GuiFactory.setSizes(namePrefixInputField, new Dimension(150, 25));
    	HBox box = new HBox(Box.createHorizontalGlue(), label, namePrefixInputField, Box.createHorizontalGlue());
    	guiObjects.add(box);


		int option = JOptionPane.showConfirmDialog(null, guiObjects.toArray(), getName() + " " + getVersion(), JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null);

		if (option == JOptionPane.OK_OPTION)
		{
			// User clicked OK, get selected parameter
			parameterNames.addAll(pane.getParameterSelection());
			namePrefix = namePrefixInputField.getText();
			return true;
		}
		return false;
	}

	@Override
	public ExternalAlgorithmResults invokeAlgorithm(SElement fcmlQueryElement, File sampleFile, File outputFolder)
	{
		SeqGeqExternalAlgorithmResults result = new SeqGeqExternalAlgorithmResults();

		if (parameterNames.size() < 0 || parameterNames.size() > 1)
		{
			result.setErrorMessage("Please select exactly one parameter.");
			return result;
		}

		List<Float> values = extractUniqueValuesForParameter(sampleFile, parameterNames.get(0));
		if (values.isEmpty())
		{
			result.setErrorMessage("No useful values found for the selected parameter.");
		}
		else if (values.size() > maxCats) 
		{
			result.setErrorMessage("Too many distinct values of the selected parameter detected, that would lead to too many sub-populations.");
		} else
			addGatingML(result, parameterNames.get(0), values);

		return result;
	}
	
	private void addGatingML(ExternalAlgorithmResults result, String parameterName, List<Float> values)
	{
		String usePrefix = namePrefix;
		if (usePrefix.isEmpty()) usePrefix = parameterName;
		
		SElement gate = new SElement("gating:Gating-ML");
		for (Float x : values)
		{
			SElement rectGateElem = new SElement("gating:RectangleGate");
			rectGateElem.setString("gating:id", usePrefix + " " + niceFloatAsString(x));
			gate.addContent(rectGateElem);
			SElement dimElem = new SElement("gating:dimension");
			dimElem.setDouble("gating:min", x - epsilon / 2);
			dimElem.setDouble("gating:max", x + epsilon / 2);
			rectGateElem.addContent(dimElem);
			SElement fcsDimElem = new SElement("data-type:fcs-dimension");
			fcsDimElem.setString("data-type:name", parameterName);
			dimElem.addContent(fcsDimElem);
		}
		result.setGatingML(gate.toString());
	}
	
	private static String niceFloatAsString(float f)
	{
		if (f == (long) f)
			return String.format("%d", (long) f);
		else
			return String.format("%s", f);
	}

	private List<Float> extractUniqueValuesForParameter(File sampleFile, String parName)
	{
		HashSet<Float> uniqueValues = new HashSet<Float>();
		BufferedReader sampleFileReader = null;
		StringTokenizer tokenizer = null;
	
		// SeqGeq is replacing all commas that are in a parameter name with semicolon; here we adapt to it. 
		parName = parName.replaceAll(",", ";");

		try {
			sampleFileReader = new BufferedReader(new FileReader(sampleFile.getAbsolutePath()));
			String line;
			while ((line = sampleFileReader.readLine()) != null)
			{
				tokenizer = new StringTokenizer(line, ",");
				if (tokenizer.hasMoreTokens()) // First column is the parameter
				{
					String gene = tokenizer.nextToken();
					if (gene.compareTo(parName) == 0) // It's the one we care about
					{
						while (tokenizer.hasMoreTokens())
						{
							String valStr = tokenizer.nextToken();
							try {
								float val = Float.parseFloat(valStr);
								val = (float) (epsilon * Math.round(val / epsilon));
								uniqueValues.add(val);
							}
							catch (NumberFormatException e) { } // Ignore that value
						}
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			if (sampleFileReader != null)
				try {
					sampleFileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

		return new ArrayList<Float>(uniqueValues);
	}
}
